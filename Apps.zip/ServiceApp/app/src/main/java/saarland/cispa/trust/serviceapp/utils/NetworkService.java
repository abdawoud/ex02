package saarland.cispa.trust.serviceapp.utils;

public class NetworkService {
    private String SERVICE_VERSION = "1.0";

    public NetworkService() {}

    public String getServiceVersion() {
        return SERVICE_VERSION;
    }
}
